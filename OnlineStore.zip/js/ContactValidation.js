// contact-validation.js

// Function to validate the contact form
function validateContactForm(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get form field values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    // Check if all fields are filled
    if (name === '' || email === '' || message === '') {
        alert('Please fill in all fields.');
        return; // Stop further execution
    }

    // Simple email validation using a regular expression
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return; // Stop further execution
    }

    // If validation passes, you can proceed with form submission or further processing
    alert('Thank you for your message! We will get back to you soon.');
    // Optionally, you can reset the form here if you want
    document.getElementById('contactForm').reset();
}

// Attach the validateContactForm function to the form's submit event
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('contactForm').addEventListener('submit', validateContactForm);
});