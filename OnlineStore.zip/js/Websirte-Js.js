$(document).ready(function() {
    const headerHTML = `
        <header>
            <h1>Retro 80s Slap Bracelet Shop</h1>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li> <!-- Link to Home -->
                    <li><a href="ShopPg.html">Products</a></li> <!-- Link to Products -->
                    <li><a href="AboutPg.html">About</a></li> <!-- Link to About -->
                    <li><a href="ContactPg.html">Contact</a></li> <!-- Link to Contact -->
                </ul>
            </nav>
        </header>
    `;

    const footerHTML = `
        <footer>
            <p>&copy; 1988 Retro 80s Slap Bracelet Shop</p>
        </footer>
    `;

    // Insert header and footer into the body
    $('body').prepend(headerHTML);
    $('body').append(footerHTML);
});