$(document).ready(function() {
    let currentIndex = 0;
    const products = [
        {
            title: "Blue Slap Bracelet",
            image: "../images/3c543851-f1a1-4fd5-8222-d96ea0a3e6cdjlr191dz_slapbracelet_blue_wcn_2017_9.jpg",
            price: "$5.99",
            description: "This vibrant blue slap bracelet is perfect for adding a pop of color to your outfit and bringing back the fun of the 80s!"
        },
        {
            title: "Pink Slap Bracelet",
            image: "../images/1570466813-112403b0-e922-11e9-bc77-bd13c33c3000.jpg",
            price: "$6.99",
            description: "This lovely pink slap bracelet is a must-have for any 80s enthusiast!"
        },
        {
            title: "Red Slap Bracelet",
            image: "../images/06ac8e34-5cab-4d82-a5a8-32432c9385b6jlr192dz_slapbracelet_red_wcn_2017_10.jpg",
            price: "$7.99",
            description: "This bold red slap bracelet is sure to make a statement!"
        }
    ];

    function updateProduct(index) {
        $('#product-title').fadeOut(200, function() {
            $(this).text(products[index].title).fadeIn(200);
        });
        $('#product-image').fadeOut(200, function() {
            $(this).attr('src', products[index].image).fadeIn(200);
        });
        $('#product-price').fadeOut(200, function() {
            $(this).text(products[index].price).fadeIn(200);
        });
        $('#product-description').fadeOut(200, function() {
            $(this).text(products[index].description).fadeIn(200);
        });
    }

    $('#next-arrow').click(function() {
        currentIndex = (currentIndex + 1) % products.length;
        updateProduct(currentIndex);
    });

    $('#prev-arrow').click(function() {
        currentIndex = (currentIndex - 1 + products.length) % products.length;
        updateProduct(currentIndex);
    });
});

// pink-product.js
$(document).ready(function() {
    $('.buy-button').click(function() {
        alert('Thank you for your purchase!');
    });
});